package vn.edu.poly.mstory.category.handle.other;

import android.content.Context;
import android.support.v4.widget.DrawerLayout;

/**
 * Created by lucius on 11/16/16.
 */

public class NavigationDrawer extends DrawerLayout {
    public NavigationDrawer(Context context) {
        super(context);
    }
}
