package vn.edu.poly.mstory.category.variable;

import java.io.InputStream;

/**
 * Created by lucius on 11/15/16.
 */

public interface FunctionDoInBackgroundVariable {
    void run(InputStream inputStream);
}
