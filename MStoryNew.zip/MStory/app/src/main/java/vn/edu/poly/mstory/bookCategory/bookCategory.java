package vn.edu.poly.mstory.bookCategory;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.TextView;
import android.widget.Toast;

import vn.edu.poly.mstory.R;
import vn.edu.poly.mstory.category.loadGridView;

public class bookCategory extends AppCompatActivity {

    GridView androidGridView;
    TextView text;
    String[] gridViewString = {
            "Truyện 1", "Truyện 2", "Truyện 3", "Truyện 4", "Truyện 5", "Truyện 6",
            "Truyện 7", "Truyện 8", "Truyện 9", "Truyện 10", "Truyện 11", "Truyện 12",
            "Truyện 13", "Truyện 14", "Truyện 15", "Truyện 16", "Truyện 17", "Truyện 18"
    };
    int[] gridViewImageId = {
            R.mipmap.bia, R.mipmap.bia, R.mipmap.bia, R.mipmap.bia, R.mipmap.bia, R.mipmap.bia,
            R.mipmap.bia, R.mipmap.bia, R.mipmap.bia, R.mipmap.bia, R.mipmap.bia, R.mipmap.bia,
            R.mipmap.bia, R.mipmap.bia, R.mipmap.bia, R.mipmap.bia, R.mipmap.bia, R.mipmap.bia,
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book_category);

        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setIcon(R.mipmap.ic_launcher);

        text = (TextView) findViewById(R.id.text);

        Intent callerIntent = getIntent();
        Bundle packageFromCaller =
                callerIntent.getBundleExtra("MyPackage");
        String title=packageFromCaller.getString("name");
        text.setText(title);

        loadGridView adapterViewAndroid = new loadGridView(bookCategory.this, gridViewString, gridViewImageId);
        androidGridView = (GridView) findViewById(R.id.grid_view_image_text);
        androidGridView.setAdapter(adapterViewAndroid);
        androidGridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view,
                                    int i, long id) {
                Toast.makeText(bookCategory.this, gridViewString[+i] + gridViewImageId[+i], Toast.LENGTH_LONG).show();
            }
        });
    }

    //button search
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.action, menu);
        return true;
    }

}
