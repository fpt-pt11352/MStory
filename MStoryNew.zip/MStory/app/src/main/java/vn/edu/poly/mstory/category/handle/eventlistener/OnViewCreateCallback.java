package vn.edu.poly.mstory.category.handle.eventlistener;

import android.view.View;

/**
 * Created by lucius on 11/16/16.
 */

public interface OnViewCreateCallback  {
    public void OnViewCreate(View view, String tag);
}
